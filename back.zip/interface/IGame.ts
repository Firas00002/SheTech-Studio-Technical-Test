export interface IGame {
    userId: number,
    game: string,
    playTime: number,
    genre: string,
    platforms: string[],
} 

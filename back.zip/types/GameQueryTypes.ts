export type gameQueryType={
    genre?:string,
    platforms?:string | object
}
export type selectTopByPlaytimeGueryType={
    genre?:string,
    platform?:string
}

export type selectTopByPlayesGueryType={
    genre?:string,
    platform?:string
}